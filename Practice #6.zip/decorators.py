import functools  # Імпортуємо модуль functools для роботи з декораторами
def log_function_call(func):
    """Декоратор для логування викликів функцій."""

    @functools.wraps(func)  # Зберігає метаінформацію (ім'я функції, документацію) оригінальної функції
    def wrapper(*args, **kwargs):  # Обгортка, яка приймає довільні аргументи і ключові аргументи
        # Логуємо ім'я функції та її аргументи
        print(f"Function '{func.__name__}' called with arguments {args} and {kwargs}")

        # Виклик оригінальної функції з аргументами
        result = func(*args, **kwargs)

        # Логуємо результат виконання функції
        print(f"Function '{func.__name__}' returned {result}")

        return result  # Повертаємо результат роботи функції

    return wrapper  # Повертаємо обгортку