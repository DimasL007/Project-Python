import os  # Модуль для взаємодії з ОС
from dotenv import load_dotenv  # Функція load_dotenv з модуля python-dotenv

# Завантаження змінних з .env файлу
load_dotenv()

# Отримамання токена
API_TOKEN = os.getenv("API_TOKEN")
