from config import API_TOKEN  # Змінна API_TOKEN з файлу config, де зберігається токен для API доступу

def fetch_data():  # Оголошуємо функцію fetch_data
    if not API_TOKEN:  # Перевіряємо, чи є значення в API_TOKEN
        raise ValueError("API_TOKEN is missing")  # Якщо токен відсутній, підкидаємо виключення (помилку)

    # Логіка для роботи з API за допомогою токену
    print(f"Using API_TOKEN: {API_TOKEN}")  # Виводимо значення токену для перевірки
    # Тут може бути код, який використовує API_TOKEN для запитів до API
    return {"data": "sample data from API"}  # Повертаємо приклад даних, що можна отримати з API

# Імпортуємо декоратор log_function_call з модуля decorators
from decorators import log_function_call

@log_function_call  # Використовуємо декоратор для логування виклику функції
def fetch_data():  # Оголошуємо функцію fetch_data, яка буде обгорнута декоратором
    if not API_TOKEN:  # Перевірка на наявність токену
        raise ValueError("API_TOKEN is missing")  # Якщо токен відсутній, підкидається виключення

    print(f"Using API_TOKEN: {API_TOKEN}")  # Виводимо значення токену
    return {"data": "sample data from API"}  # Повертаємо дані з API