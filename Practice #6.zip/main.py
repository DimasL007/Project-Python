from utils import fetch_data  # Імпорт функції fetch_data з модуля utils
def main():  # Головна функція програми
    print("Starting application...")  # Виводимо повідомлення про запуск програми

    data = fetch_data()  # Викликаємо функцію fetch_data (ймовірно, задекоровану)
    print(f"Received data: {data}")  # Виводимо отримані дані

# Умовний оператор, щоб переконатися, що код виконується лише при прямому запуску файлу
if __name__ == "__main__":
    main()  # Викликаємо головну функцію